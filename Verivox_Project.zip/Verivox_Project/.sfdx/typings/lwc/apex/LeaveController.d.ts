declare module "@salesforce/apex/LeaveController.getRemainingVacation" {
  export default function getRemainingVacation(): Promise<any>;
}
declare module "@salesforce/apex/LeaveController.calculateWorkingDays" {
  export default function calculateWorkingDays(param: {startDate: any, endDate: any}): Promise<any>;
}
declare module "@salesforce/apex/LeaveController.saveLeaveApplication" {
  export default function saveLeaveApplication(param: {startDate: any, endDate: any, type: any}): Promise<any>;
}
