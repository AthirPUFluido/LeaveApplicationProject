import { LightningElement, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getRemainingVacation from '@salesforce/apex/LeaveController.getRemainingVacation'; // Apex class
import saveLeaveApplication from '@salesforce/apex/LeaveController.saveLeaveApplication';
import {  getObjectInfo, getPicklistValues } from "lightning/uiObjectInfoApi";
import TYPE_FIELD from "@salesforce/schema/Application_for_Leave__c.Type__c";
import APPLICATIONFORLEAVE_OBJECT from "@salesforce/schema/Application_for_Leave__c";
import calculateWorkingDays from '@salesforce/apex/LeaveController.calculateWorkingDays'; 


export default class ApplicationForLeave extends LightningElement {
  startDate = '';
  endDate = '';
  type = '';
  typeOptions;
  appForLeaveRecordTypeId;
    balanceVacationDays;
     // Fetch remaining vacation days
    @wire (getRemainingVacation) wiredBalanceVacationDays({ error, data }) {
        if (data) {
            this.balanceVacationDays = data;
        } else if (error) {
            this.error = error;
            this.balanceVacationDays = undefined;
        }
    }
    @wire(getObjectInfo, { objectApiName: APPLICATIONFORLEAVE_OBJECT })
  results({ error, data }) {
    if (data) {
      this.appForLeaveRecordTypeId = data.defaultRecordTypeId;
      this.error = undefined;
    } else if (error) {
      this.error = error;
      this.accountRecordTypeId = undefined;
    }
  } 
    @wire(getPicklistValues, {   recordTypeId: "$appForLeaveRecordTypeId",fieldApiName: TYPE_FIELD })
    picklistResults({ error, data }) {
      if (data) {
        this.typeOptions =  data.values;
        this.error = undefined;
      } else if (error) {
        this.error = error;
        this.typeOptions = undefined;
      }
    }
    handleStartDateChange(event) {
        this.startDate = event.target.value;
      }
    
      handleEndDateChange(event) {
        this.endDate = event.target.value;
      }
    
      handleTypeChange(event) {
        this.type = event.detail.value;
      }
    handleSubmit() {
      
        // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0]; // Converts current date to 'YYYY-MM-DD' format

    // Validate if the start date is before today
    if (this.startDate < today) {
      this.showErrorToast('Start date cannot be in the past.');
      return; // Prevent form submission
    }
    // Validate if the end date is earlier than the start date
    if (this.endDate < this.startDate) {
        this.showErrorToast('End date cannot be earlier than the start date.');
        return; // Prevent form submission
      }
            // Call Apex method to calculate working days
        calculateWorkingDays({ startDate: this.startDate, endDate: this.endDate })
        .then(workingDays => {
            // Check if working days exceed 3 weeks (15 working days)
            if(workingDays > this.balanceVacationDays){
                this.showErrorToast('You dont have enough leave to apply.');
                return; // Prevent form submission
            }
            if (workingDays > 15) {
                this.showErrorToast('Leave duration cannot exceed 3 weeks of working days.');
            } else {
                // Proceed with submission
                this.saveLeaveApplication();
            }
        })
        .catch(error => {
            this.showErrorToast(error.body.message);
        });
        
    }
    saveLeaveApplication() {
        saveLeaveApplication({
            startDate: this.startDate,
            endDate: this.endDate,
            type: this.type
        })
        .then(() => {
            this.showSuccessToast();
            this.clearForm();
        })
        .catch(error => {
            this.showErrorToast(error.message);
        });
    }
      showSuccessToast() {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: 'Leave application saved successfully!',
                variant: 'success',
            })
        );
    }
    showErrorToast(errorMessage) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message: errorMessage,
                variant: 'error',
            })
        );
    }
      clearForm() {
        this.startDate = '';
        this.endDate = '';
        this.type = '';
      }
}